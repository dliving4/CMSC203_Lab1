import java.util.Scanner;

public class MovieDriver {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		String title = "";
		String rating = "";
		String sold = "";
		
			System.out.println("Enter the name of a movie");
			title = scan.nextLine();
			
			System.out.println("Enter the rating of the movie");
			rating = scan.nextLine();
		
			System.out.println("Enter the number of tickets sold for this movie");
			sold = scan.nextLine();
			int numSold = Integer.parseInt(sold);
			
			Movie movie = new Movie(title, rating, numSold);
			
			System.out.println(movie.toString());
			
			
			System.out.println("goodbye");
			
		scan.close();
	}
}