import java.util.Scanner;

public class MovieDriver {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		boolean running = true;
		String input = "";
		String title = "";
		String rating = "";
		String sold = "";
		
		while(running == true){
			System.out.println("Enter the name of a movie");
			title = scan.nextLine();
			
			System.out.println("Enter the rating of the movie");
			rating = scan.nextLine();
		
			System.out.println("Enter the number of tickets sold for this movie");
			sold = scan.nextLine();
			int numSold = Integer.parseInt(sold);
			
			Movie movie = new Movie(title, rating, numSold);
			
			System.out.println(movie.toString());
			
			
			System.out.println("goodbye");
			
			System.out.println("Do you want to enter another? (y or n)");
			input = scan.nextLine();

			
			if(input.equals("n")) {
				running = false;
				System.out.println("goodbye");
				break;
			} else {
				continue;
			} 
			
		}
		
		scan.close();
	}
}
